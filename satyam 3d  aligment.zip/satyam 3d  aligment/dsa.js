import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-app.js";
            // import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-analytics.js";
            import { getDatabase, ref, set, get, child } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-database.js";
            // import { getDatabase, ref, set, get, child } from "https://www.gstatic.com/firebasejs/9.19.1/firebase-database.js";
              
            
            const firebaseConfig = {
                apiKey: "AIzaSyAkC4aaQUiXxdItchyxqzcvqiiwtxGcMac",
                authDomain: "infouser-d03d3.firebaseapp.com",
                projectId: "infouser-d03d3",
                storageBucket: "infouser-d03d3.appspot.com",
                messagingSenderId: "1065808735407",
                appId: "1:1065808735407:web:ffd9503b8553d0a241b85a"
            };
            
            // Initialize Firebase
            // Initialize Firebase
            const app = initializeApp(firebaseConfig);
            
            //get ref to database services
                      const db = getDatabase(app);
            
                      document.getElementById("submit").addEventListener('click', function(e){
                       e.preventDefault();
                       set(ref(db, 'user/' + document.getElementById("username").value),
                       {
            
                         username: document.getElementById("username").value,
                         email: document.getElementById("email").value,
                         PhoneNumber: document.getElementById("specialised").value
            
                       });
                         alert("Login Sucessfull  !");
                      })


